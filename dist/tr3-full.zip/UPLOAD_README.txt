tigraoRADIO TR3 - codebase completa (HEAD: 7e75f1a)
=====================================================

Este zip contem todos os arquivos rastreados pelo git no estado atual do
projeto, prontos pra subir numa branch vazia no GitHub.

COMO SUBIR NUMA BRANCH NOVA (web UI):
1. Em github.com/romastefale/TR3, abra o seletor de branch.
2. Digite o nome da nova branch (ex.: month) - o GitHub vai oferecer
   "Create branch month from main". NAO crie a partir de main (ja tem
   os arquivos antigos). Use a opcao de branch vazia se disponivel, OU:

ALTERNATIVA RECOMENDADA (mais simples, sem comando local):
1. Crie a branch "month" no GitHub a partir de main mesmo.
2. Em outro lugar (Codespace, ou local), troque pra essa branch e
   substitua tudo pelos arquivos deste zip.

OU, ainda mais simples - upload em massa pela web:
1. Em github.com/romastefale/TR3 cria a branch month.
2. Em cada pasta voce pode arrastar arquivos pelo botao "Add file >
   Upload files". Funciona pasta por pasta - o GitHub aceita drag-and-drop
   de pastas inteiras (Chrome/Edge).
3. Depois de subir tudo, no Railway aponte o servico de teste pra branch month.

LEMBRE-SE:
- A pasta live_media_worker/ FOI REMOVIDA neste estado. Se ela existir
  na branch antiga, delete pela web (abre o arquivo > lixeira).
- Total de arquivos neste zip: 54
