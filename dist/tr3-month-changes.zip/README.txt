tigraoRADIO TR3 — pacote de mudanças do redesign /weekfm e /monthfm
====================================================================

Base: origin/main = fbcb506
Topo: main local  = df482f6
5 commits adiante de origin/main (ver COMMITS.txt).

------------------------------------------------------------
COMO APLICAR NO GITHUB (via interface web)
------------------------------------------------------------

OPÇÃO A — usando o patch (mais fiel)
1. Clone o repo localmente OU abra um Codespace no GitHub.
2. Cria uma branch nova: git checkout -b month origin/main
3. Aplica o patch: git apply changes.patch
4. Commit e push: git add -A && git commit -m "Redesign month/week cards" && git push -u origin month

OPÇÃO B — só copiar os arquivos (mais simples, sem git local)
1. No GitHub, vai em romastefale/TR3, clica no seletor de branch e cria
   uma branch nova chamada "month" a partir de "main".
2. Já na branch "month", substitui o conteúdo dos arquivos abaixo
   pelos da pasta modified/ (mesmo caminho relativo):
     - .replit                              (novo arquivo na raiz)
     - app/bot/telegram.py
     - app/services/lastfm_capsule.py
     - app/services/lastfm_weekly.py
     - app/services/monthfm_card.py
     - app/templates/monthfm_card.html
   Pra cada um: abre o arquivo no GitHub, clica no lápis (Edit), apaga
   tudo, cola o conteúdo de modified/<mesmo caminho>, commit direto
   na branch month.
3. DELETA estes arquivos/pastas que saíram do projeto:
     - app/services/live_media.py
     - live_media_worker/Dockerfile
     - live_media_worker/main.py
     - live_media_worker/requirements.txt
     - live_media_worker/start.py
   (No GitHub: abre o arquivo, ícone de lixeira no canto superior
    direito → commit na branch month. Depois que a pasta live_media_worker/
    estiver vazia o GitHub remove ela sozinho.)

------------------------------------------------------------
DEPOIS DO PUSH
------------------------------------------------------------
- Railway: aponta o serviço de teste pra branch "month" (Settings →
  Service → Source → Branch). NÃO mexe no serviço que usa "main".
- main continua intocado, pronto pra ser promovido depois que validar.

------------------------------------------------------------
ARQUIVOS NESTE ZIP
------------------------------------------------------------
- README.txt           este arquivo
- COMMITS.txt          lista dos 5 commits que estão no pacote
- changes.patch        diff unified pronto pra `git apply`
- modified/            arquivos no estado atual, prontos pra copiar
