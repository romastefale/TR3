from __future__ import annotations

import base64
import html
import io
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from PIL import Image, ImageDraw, ImageFont

logger = logging.getLogger(__name__)

CARD_WIDTH = 1080
CARD_HEIGHT = 1350
DEFAULT_BOT_NAME = "tigraoRADIO"
TEMPLATE_PATH = Path(__file__).resolve().parents[1] / "templates" / "monthfm_card.html"

ThemeName = Literal["dark"]

THEMES: dict[str, dict[str, str]] = {
    "dark": {
        "bg": "#0B0A1A",
        "surface": "#161329",
        "surface_soft": "#1C1A33",
        "text": "#F4F1FF",
        "muted": "#A8A3C6",
        "blue": "#5B9CFF",
        "green": "#3FE0A6",
        "purple": "#B58CFE",
        "line": "rgba(181,140,254,.28)",
    },
}

FALLBACK_HERO_IMAGE = (
    "data:image/svg+xml;utf8,"
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1024 1024'>"
    "<defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'>"
    "<stop offset='0%' stop-color='%235B9CFF'/>"
    "<stop offset='55%' stop-color='%23B58CFE'/>"
    "<stop offset='100%' stop-color='%233FE0A6'/>"
    "</linearGradient></defs>"
    "<rect width='1024' height='1024' fill='url(%23g)'/>"
    "<circle cx='760' cy='280' r='220' fill='rgba(255,255,255,.16)'/>"
    "<circle cx='260' cy='740' r='260' fill='rgba(0,0,0,.18)'/>"
    "</svg>"
)

FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
]
BOLD_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
]
ITALIC_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansOblique.ttf",
]


@dataclass(frozen=True)
class CardArtist:
    name: str
    count: int


@dataclass(frozen=True)
class CardTrack:
    title: str
    artist: str
    plays: int


@dataclass(frozen=True)
class MonthfmCardData:
    title: str
    bot_name: str = DEFAULT_BOT_NAME
    theme: ThemeName = "dark"
    period_label: str = "EXTRATO"
    period_value: str = ""
    hero_image_url: str | None = None
    hero_image_bytes: bytes | None = None
    hero_track: str = ""
    hero_artist: str = ""
    hero_plays: int = 0
    top_artists: tuple[CardArtist, ...] = ()
    top_tracks: tuple[CardTrack, ...] = ()
    # Legacy fields kept for backward compatibility with text builders.
    # They are no longer rendered on the card image.
    album_name: str = ""
    album_artist: str = ""
    album_count: int = 0
    total_scrobbles: int = 0
    minutes: int | None = None


def _escape(value: object) -> str:
    return html.escape(str(value or ""), quote=True)


def _format_number(value: int | None) -> str:
    if value is None:
        return "0"
    return f"{int(value):,}".replace(",", ".")


def _row_number(index: int) -> str:
    return f"{index:02d}"


def _artist_rows(items: tuple[CardArtist, ...]) -> str:
    rows: list[str] = []
    for idx, item in enumerate(items[:5], 1):
        rows.append(
            "<div class=\"row\">"
            f"<div class=\"rank\">{_row_number(idx)}</div>"
            f"<div class=\"name\">{_escape(item.name)}</div>"
            f"<div class=\"count\">{_format_number(item.count)}</div>"
            "</div>"
        )
    while len(rows) < 5:
        idx = len(rows) + 1
        rows.append(
            "<div class=\"row\">"
            f"<div class=\"rank\">{_row_number(idx)}</div>"
            "<div class=\"name\">—</div>"
            "<div class=\"count\">0</div>"
            "</div>"
        )
    return "\n".join(rows)


def _track_rows(items: tuple[CardTrack, ...]) -> str:
    rows: list[str] = []
    for idx, item in enumerate(items[:5], 1):
        rows.append(
            "<div class=\"row\">"
            f"<div class=\"rank\">{_row_number(idx)}</div>"
            "<div class=\"name\">"
            f"{_escape(item.title)}"
            f"<span class=\"sub\">{_escape(item.artist)}</span>"
            "</div>"
            f"<div class=\"count\">{_format_number(item.plays)}</div>"
            "</div>"
        )
    while len(rows) < 5:
        idx = len(rows) + 1
        rows.append(
            "<div class=\"row\">"
            f"<div class=\"rank\">{_row_number(idx)}</div>"
            "<div class=\"name\">—<span class=\"sub\">—</span></div>"
            "<div class=\"count\">0</div>"
            "</div>"
        )
    return "\n".join(rows)


def _hero_data_uri(raw: bytes | None, *, max_dim: int = 640) -> str | None:
    """Normalize remote image bytes into a JPEG data URI safe to embed in HTML.

    Caps the largest dimension to keep the page small enough for Chromium to
    rasterize without delay; preserves the best quality the source provides
    up to that bound.
    """
    if not raw:
        return None
    try:
        with Image.open(io.BytesIO(raw)) as img:
            img = img.convert("RGB")
            largest = max(img.size)
            if largest > max_dim:
                scale = max_dim / largest
                img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.LANCZOS)
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=90, optimize=True)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        logger.debug("HERO_DATA_URI_FAILED", exc_info=True)
        return None


def _fit_square(image: Image.Image, size: int) -> Image.Image:
    image = image.convert("RGB")
    width, height = image.size
    if width <= 0 or height <= 0:
        return Image.new("RGB", (size, size), (24, 24, 24))
    scale = max(size / width, size / height)
    new_size = (max(size, int(width * scale)), max(size, int(height * scale)))
    image = image.resize(new_size, Image.LANCZOS)
    left = (image.width - size) // 2
    top = (image.height - size) // 2
    return image.crop((left, top, left + size, top + size))


def _period_font_size(value: str) -> int:
    """Pick a Bebas Neue size that keeps the period inside the 952px column."""
    length = len(value or "")
    if length <= 12:
        return 138
    if length <= 16:
        return 116
    if length <= 20:
        return 96
    if length <= 26:
        return 78
    return 64


def build_monthfm_card_html(data: MonthfmCardData) -> str:
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    theme = THEMES.get(data.theme, THEMES["dark"])
    hero_track = data.hero_track or (data.top_tracks[0].title if data.top_tracks else "—")
    hero_artist = data.hero_artist or (data.top_tracks[0].artist if data.top_tracks else "—")
    hero_plays = data.hero_plays or (data.top_tracks[0].plays if data.top_tracks else 0)
    period_value = data.period_value or data.title
    # SECURITY: never let Chromium fetch a remote URL directly. Only inline
    # validated, re-encoded bytes (data URI) or the local SVG placeholder.
    hero_image_src = _hero_data_uri(data.hero_image_bytes) or FALLBACK_HERO_IMAGE
    values = {
        **theme,
        "bot_name": _escape(data.bot_name),
        "period_label": _escape(data.period_label),
        "period_value": _escape(period_value),
        "period_font_size": str(_period_font_size(period_value)),
        "hero_image": _escape(hero_image_src),
        "hero_track": _escape(hero_track),
        "hero_artist": _escape(hero_artist),
        "hero_plays": _format_number(hero_plays),
        "artist_rows": _artist_rows(data.top_artists),
        "track_rows": _track_rows(data.top_tracks),
        "minutes": _format_number(data.minutes),
    }
    for key, value in values.items():
        template = template.replace("{{ " + key + " }}", str(value))
    return template


def _hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.strip().lstrip("#")
    return (int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def _load_font(size: int, *, bold: bool = False, italic: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = ITALIC_FONT_CANDIDATES if italic else BOLD_FONT_CANDIDATES if bold else FONT_CANDIDATES
    for path in candidates:
        try:
            if Path(path).exists():
                return ImageFont.truetype(path, size=size)
        except Exception:
            continue
    return ImageFont.load_default()


def _ellipsize(text: str, max_chars: int) -> str:
    clean = " ".join(str(text or "").split())
    if len(clean) <= max_chars:
        return clean
    return clean[: max_chars - 1].rstrip() + "…"


def _render_pillow_card(data: MonthfmCardData) -> bytes | None:
    """Simplified fallback renderer used when Playwright/Chromium is unavailable.

    Matches the dark/blue/green/purple palette of the HTML template but
    without the display font (Bebas Neue) — uses DejaVu Bold instead.
    """
    try:
        theme = THEMES["dark"]
        bg = _hex_to_rgb(theme["bg"])
        surface = _hex_to_rgb(theme["surface"])
        surface_soft = _hex_to_rgb(theme["surface_soft"])
        text_color = _hex_to_rgb(theme["text"])
        muted = _hex_to_rgb(theme["muted"])
        blue = _hex_to_rgb(theme["blue"])
        green = _hex_to_rgb(theme["green"])
        purple = _hex_to_rgb(theme["purple"])

        image = Image.new("RGB", (CARD_WIDTH, CARD_HEIGHT), bg)
        draw = ImageDraw.Draw(image)

        # Subtle radial-ish glows using elliptical fills (approximation).
        glow = Image.new("RGB", (CARD_WIDTH, CARD_HEIGHT), bg)
        glow_draw = ImageDraw.Draw(glow)
        glow_draw.ellipse((-220, -260, 560, 480), fill=(blue[0] // 4 + bg[0] // 2, blue[1] // 4 + bg[1] // 2, blue[2] // 4 + bg[2] // 2))
        glow_draw.ellipse((620, -200, 1320, 520), fill=(purple[0] // 4 + bg[0] // 2, purple[1] // 4 + bg[1] // 2, purple[2] // 4 + bg[2] // 2))
        glow_draw.ellipse((180, 1100, 1080, 1700), fill=(green[0] // 5 + bg[0] // 2, green[1] // 5 + bg[1] // 2, green[2] // 5 + bg[2] // 2))
        image = Image.blend(image, glow, alpha=0.55)
        draw = ImageDraw.Draw(image)

        # Fonts
        brand_font = _load_font(32, bold=True)
        period_label_font = _load_font(28, bold=True)
        # Pillow lacks Bebas Neue; DejaVu Bold is wider. Scale ~70% of the HTML size.
        period_value_font = _load_font(max(40, int(_period_font_size(data.period_value or data.title) * 0.7)), bold=True)
        hero_label_font = _load_font(20, bold=True)
        hero_track_font = _load_font(40, bold=True)
        hero_artist_font = _load_font(26, italic=True)
        hero_plays_font = _load_font(28, bold=True)
        section_font = _load_font(24, bold=True)
        rank_font = _load_font(36, bold=True)
        name_font = _load_font(28, bold=True)
        sub_font = _load_font(19, italic=True)
        count_font = _load_font(30, bold=True)
        minutes_font = _load_font(140, bold=True)
        minutes_word_font = _load_font(52, bold=True)
        minutes_hint_font = _load_font(20, bold=True)

        x = 64
        y = 56

        # Header — brand
        draw.text((x, y), f"♫ {data.bot_name}", font=brand_font, fill=blue)
        y += 60

        # Period label + value
        draw.text((x, y), data.period_label.upper(), font=period_label_font, fill=purple)
        y += 40
        draw.text((x, y), (data.period_value or data.title).upper(), font=period_value_font, fill=text_color)
        y += 130

        # Hero card
        hero_top = y
        hero_h = 236
        draw.rounded_rectangle((x - 4, hero_top, CARD_WIDTH - x + 4, hero_top + hero_h), radius=26, fill=surface)
        cover_size = 184
        cover_box = (x + 22, hero_top + 26, x + 22 + cover_size, hero_top + 26 + cover_size)
        pasted_real_cover = False
        if data.hero_image_bytes:
            try:
                with Image.open(io.BytesIO(data.hero_image_bytes)) as raw_cover:
                    cover = _fit_square(raw_cover, cover_size)
                mask = Image.new("L", (cover_size, cover_size), 0)
                ImageDraw.Draw(mask).rounded_rectangle((0, 0, cover_size, cover_size), radius=18, fill=255)
                image.paste(cover, (cover_box[0], cover_box[1]), mask)
                draw = ImageDraw.Draw(image)
                pasted_real_cover = True
            except Exception:
                logger.debug("MONTHFM_CARD_PILLOW_COVER_FAILED", exc_info=True)
        if not pasted_real_cover:
            draw.rounded_rectangle(cover_box, radius=18, fill=surface_soft)
            draw.ellipse((cover_box[0] + 40, cover_box[1] + 40, cover_box[2] - 40, cover_box[3] - 40), fill=purple)
            draw.ellipse((cover_box[0] + 70, cover_box[1] + 70, cover_box[2] - 70, cover_box[3] - 70), fill=blue)

        info_x = cover_box[2] + 32
        info_y = hero_top + 30
        draw.text((info_x, info_y), "MAIS OUVIDA NO PERÍODO", font=hero_label_font, fill=muted)
        hero_track = data.hero_track or (data.top_tracks[0].title if data.top_tracks else "—")
        hero_artist = data.hero_artist or (data.top_tracks[0].artist if data.top_tracks else "—")
        hero_plays = data.hero_plays or (data.top_tracks[0].plays if data.top_tracks else 0)
        draw.text((info_x, info_y + 32), _ellipsize(hero_track, 22), font=hero_track_font, fill=text_color)
        draw.text((info_x, info_y + 82), _ellipsize(hero_artist, 26), font=hero_artist_font, fill=green)
        draw.text((info_x, info_y + 122), f"{_format_number(hero_plays)} plays", font=hero_plays_font, fill=blue)

        y = hero_top + hero_h + 36

        # Columns
        left_x = x
        right_x = x + 480
        list_width = 416

        draw.text((left_x, y), "✦  TOP ARTISTAS", font=section_font, fill=muted)
        draw.text((right_x, y), "♫  TOP MÚSICAS", font=section_font, fill=muted)

        row_y = y + 50
        for idx in range(5):
            item = data.top_artists[idx] if idx < len(data.top_artists) else None
            name = item.name if item else "—"
            count = item.count if item else 0
            draw.text((left_x, row_y), f"{idx + 1:02d}", font=rank_font, fill=purple)
            draw.text((left_x + 60, row_y + 4), _ellipsize(name, 20), font=name_font, fill=text_color)
            count_text = _format_number(count)
            bbox = draw.textbbox((0, 0), count_text, font=count_font)
            draw.text((left_x + list_width - (bbox[2] - bbox[0]), row_y + 4), count_text, font=count_font, fill=green)
            row_y += 64

        row_y = y + 50
        for idx in range(5):
            item = data.top_tracks[idx] if idx < len(data.top_tracks) else None
            title = item.title if item else "—"
            artist = item.artist if item else "—"
            plays = item.plays if item else 0
            draw.text((right_x, row_y), f"{idx + 1:02d}", font=rank_font, fill=purple)
            draw.text((right_x + 60, row_y), _ellipsize(title, 18), font=name_font, fill=text_color)
            draw.text((right_x + 60, row_y + 36), _ellipsize(artist, 22), font=sub_font, fill=muted)
            count_text = _format_number(plays)
            bbox = draw.textbbox((0, 0), count_text, font=count_font)
            draw.text((right_x + list_width - (bbox[2] - bbox[0]), row_y + 8), count_text, font=count_font, fill=green)
            row_y += 64

        # Footer
        footer_top = CARD_HEIGHT - 220
        draw.line((x, footer_top, CARD_WIDTH - x, footer_top), fill=purple, width=2)
        minutes_text = _format_number(data.minutes)
        draw.text((x, footer_top + 24), minutes_text, font=minutes_font, fill=green)
        minutes_bbox = draw.textbbox((x, footer_top + 24), minutes_text, font=minutes_font)
        minutes_right = minutes_bbox[2]
        word_x = max(minutes_right + 30, CARD_WIDTH - x - 240)
        draw.text((word_x, footer_top + 60), "minutos", font=minutes_word_font, fill=text_color)
        draw.text((word_x, footer_top + 120), "NO PERÍODO", font=minutes_hint_font, fill=muted)

        output = io.BytesIO()
        image.save(output, format="JPEG", quality=92, optimize=True)
        return output.getvalue()
    except Exception:
        logger.exception("MONTHFM_CARD_PILLOW_RENDER_FAILED | period=%s", data.period_value or data.title)
        return None


async def render_monthfm_card(data: MonthfmCardData) -> bytes | None:
    """Render the monthly/weekly extract card to JPEG bytes.

    The preferred renderer is Playwright/Chromium. If it is unavailable in the
    deploy environment, the function falls back to a pure Pillow card renderer.
    """
    try:
        from playwright.async_api import async_playwright  # type: ignore[import-not-found]
    except Exception:
        logger.warning("MONTHFM_CARD_RENDER_UNAVAILABLE | reason=playwright_import_failed", exc_info=True)
        return _render_pillow_card(data)

    html_content = build_monthfm_card_html(data)
    browser = None
    try:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(args=["--no-sandbox"])
            page = await browser.new_page(
                viewport={"width": CARD_WIDTH, "height": CARD_HEIGHT},
                device_scale_factor=1,
            )
            await page.set_content(html_content, wait_until="networkidle", timeout=20000)
            try:
                await page.evaluate("document.fonts && document.fonts.ready")
            except Exception:
                logger.debug("MONTHFM_CARD_FONTS_READY_FAILED", exc_info=True)
            return await page.screenshot(type="jpeg", quality=92, full_page=False, timeout=15000)
    except Exception:
        logger.exception(
            "MONTHFM_CARD_RENDER_FAILED | theme=%s | period=%s",
            data.theme,
            data.period_value or data.title,
        )
        return _render_pillow_card(data)
    finally:
        if browser is not None:
            try:
                await browser.close()
            except Exception:
                logger.warning("MONTHFM_CARD_BROWSER_CLOSE_FAILED", exc_info=True)
